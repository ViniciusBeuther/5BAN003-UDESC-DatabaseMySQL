package src.Classes;

public class UnidadesMedida {
    protected String sigla;
    protected String nome;
}
